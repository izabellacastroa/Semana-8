﻿public class Empleado
{
    public string Nombre { get; set; }
    public decimal Salario { get; set; }
    public string TipoEmpleado { get; set; }
}

public class EmpleadoTiempoCompleto : Empleado
{
    public int HorasTrabajadas { get; set; }

    public decimal CalcularSalarioTotal()
    {
        return Salario * HorasTrabajadas;
    }
}

public class EmpleadoTiempoParcial : Empleado
{
    public int HorasSemanales { get; set; }

    public decimal CalcularSalarioSemanal()
    {
        return Salario * HorasSemanales;
    }
}

public class Contratista : Empleado
{
    public int DuracionContrato { get; set; }

    public decimal CalcularCostoContrato()
    {
        return Salario * DuracionContrato;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        EmpleadoTiempoCompleto empleado1 = new EmpleadoTiempoCompleto
        {
            Nombre = "Luis",
            Salario = 22,
            TipoEmpleado = "Tiempo Completo",
            HorasTrabajadas = 38
        };

        EmpleadoTiempoParcial empleado2 = new EmpleadoTiempoParcial
        {
            Nombre = "Luna",
            Salario = 16,
            TipoEmpleado = "Tiempo Parcial",
            HorasSemanales = 18
        };

        Contratista contratista1 = new Contratista
        {
            Nombre = "Allison",
            Salario = 36,
            TipoEmpleado = "Contratista",
            DuracionContrato = 8
        };

        decimal salarioTotalEmpleado1 = empleado1.CalcularSalarioTotal();
        decimal salarioSemanalEmpleado2 = empleado2.CalcularSalarioSemanal();
        decimal costoContratoContratista1 = contratista1.CalcularCostoContrato();

        Console.WriteLine("Salario total de " + empleado1.Nombre + ": $" + salarioTotalEmpleado1);
        Console.WriteLine("Salario semanal de " + empleado2.Nombre + ": $" + salarioSemanalEmpleado2);
        Console.WriteLine("Costo total del contrato de " + contratista1.Nombre + ": $" + costoContratoContratista1);
    }
}


