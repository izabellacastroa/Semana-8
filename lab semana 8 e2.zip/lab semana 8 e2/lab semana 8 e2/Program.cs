﻿using System;
public class Libro
{
    public string Titulo { get; set; }
    public string Autor { get; set; }
    public int CopiasDisponibles { get; set; }
}

public class Usuario
{
    public string Nombre { get; set; }
    public int NumeroIdentificacion { get; set; }
    public List<Libro> LibrosPrestados { get; set; }
}

public class Biblioteca
{
    public List<Libro> Libros { get; set; }
    public List<Usuario> Usuarios { get; set; }

    public Biblioteca()
    {
        Libros = new List<Libro>();
        Usuarios = new List<Usuario>();
    }

    public void PrestarLibro(Usuario usuario, Libro libro)
    {
        if (libro.CopiasDisponibles > 0)
        {
            libro.CopiasDisponibles--;
            usuario.LibrosPrestados.Add(libro);
            Console.WriteLine("El libro '" + libro.Titulo + "' ha sido prestado a " + usuario.Nombre);
        }
        else
        {
            Console.WriteLine("No hay copias disponibles del libro '" + libro.Titulo + "'");
        }
    }

    public void DevolverLibro(Usuario usuario, Libro libro)
    {
        if (usuario.LibrosPrestados.Contains(libro))
        {
            libro.CopiasDisponibles++;
            usuario.LibrosPrestados.Remove(libro);
            Console.WriteLine("El libro '" + libro.Titulo + "' ha sido devuelto por " + usuario.Nombre);
        }
        else
        {
            Console.WriteLine("El usuario " + usuario.Nombre + " no tiene prestado el libro '" + libro.Titulo + "'");
        }
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Biblioteca biblioteca = new Biblioteca();

        Libro libro1 = new Libro { Titulo = "Libro 1", Autor = "Autor 1", CopiasDisponibles = 3 };
        Libro libro2 = new Libro { Titulo = "Libro 2", Autor = "Autor 2", CopiasDisponibles = 1 };

        Usuario usuario1 = new Usuario { Nombre = "Usuario 1", NumeroIdentificacion = 1, LibrosPrestados = new List<Libro>() };
        Usuario usuario2 = new Usuario { Nombre = "Usuario 2", NumeroIdentificacion = 2, LibrosPrestados = new List<Libro>() };

        biblioteca.Libros.Add(libro1);
        biblioteca.Libros.Add(libro2);
        biblioteca.Usuarios.Add(usuario1);
        biblioteca.Usuarios.Add(usuario2);

        biblioteca.PrestarLibro(usuario1, libro1);
        biblioteca.PrestarLibro(usuario2, libro1);
        biblioteca.PrestarLibro(usuario1, libro2);
        biblioteca.PrestarLibro(usuario2, libro2);

        biblioteca.DevolverLibro(usuario1, libro1);
        biblioteca.DevolverLibro(usuario2, libro2);
    }
}


