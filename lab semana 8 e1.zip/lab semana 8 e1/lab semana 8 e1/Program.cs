﻿using System;
public class CollatzSequence
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Ingrese un número entero positivo:");
        int n = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Secuencia de Collatz para el número " + n + ":");
        Console.Write(n + " ");

        while (n != 1)
        {
            if (n % 2 == 0)
            {
                n = n / 2;
            }
            else
            {
                n = (n * 3) + 1;
            }

            Console.Write(n + " ");
        }
    }
}


